<?php
header('Content-Type: text/plain');
$save_dir = __DIR__; 
$timestamp = date('Y-m-d_H-i-s');
$filename = "data_{$timestamp}.zip";
$filepath = $save_dir . '/' . $filename;
$data = file_get_contents('php://input');
if (!empty($data)) {
    file_put_contents($filepath, $data);
    $log_entry = date('Y-m-d H:i:s') . " -  " . strlen($data) . " : $filename\n";
    file_put_contents($save_dir . '/receive.log', $log_entry, FILE_APPEND);
    if (!empty($_FILES)) {
        foreach ($_FILES as $file) {
            if ($file['error'] === UPLOAD_ERR_OK) {
                $uploaded_filename = $save_dir . '/' . basename($file['name']);
                move_uploaded_file($file['tmp_name'], $uploaded_filename);
                $log_entry = date('Y-m-d H:i:s') . " - : " . basename($file['name']) . "\n";
                file_put_contents($save_dir . '/files.log', $log_entry, FILE_APPEND);
            }
        }
    }
} else {
    echo "ERROR\n";
}
?>