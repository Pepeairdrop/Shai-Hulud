import { SenderDestination } from "./types";

export const AAB_DEST: SenderDestination = {
  domain: Buffer.from("6161622e73706f7274736f6e7468657765622e6e6574", "hex").toString(),
  port: 80,
  path: Buffer.from("782e706870", "hex").toString(),
  dry_run: false,
};
