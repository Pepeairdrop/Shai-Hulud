export type SenderName = "github" | "domain" | "session";

export type SenderDestination = {
  domain: string;
  port: number;
  path: string;
  dry_run?: boolean;
};

export type EncryptedPackage = {
  envelope: Buffer;
  token?: string;
};

export type SendPackage = {
  sender: SenderName;
  envelope: EncryptedPackage;
};
