import { logUtil } from "../../utils/logger";
import type { Sender } from "../base";
import type { SenderFactory } from "../senderFactory";
import type { SenderDestination } from "../types";
import { DomainSender } from "./sender";

declare function scramble(str: string): string;

export class DomainSenderFactory implements SenderFactory {
  private readonly config: SenderDestination;
  constructor(config: SenderDestination) {
    this.config = config;
  }

  async tryCreate(): Promise<Sender | null> {
    const primary = new DomainSender(this.config);
    return primary;
  }
}
